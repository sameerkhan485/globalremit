const express = require('express');
const nodemailer = require('nodemailer');

const router = express.Router();
const config = require('../../config');

router.post('/send', (req, res, next) => {

    const transport = {
        host: 'server.theafricanwear.com',
        port: 587,
        auth: {
            user: config.USER,
            pass: config.PASS
        }
    }
    
    const transporter = nodemailer.createTransport(transport);

    let newMessage = {
        fullName: req.body.fullName,
        email: req.body.email,
        telephone: req.body.telephone,
        textMessage: req.body.textMessage
    }

    let mailOptions = {
        from: `${newMessage.fullName} <${newMessage.email}>`,
        to: `${config.USER}`,
        subject: 'Message From Contact Form',
        html: `<div>
            <div><b>Full Name: </b> ${newMessage.fullName}</div><br />
            <div><b>E-mail: </b> ${newMessage.email}</div><br />
            <div><b>Telephone: </b> ${newMessage.telephone}</div><br />
            <div><b>Message: </b> ${newMessage.textMessage}</div><br />
        </div>`
    }

    let mailReplyOptions = {
        from: `Global Remit FS <${config.USER}>`,
        to: `${newMessage.email}`,
        subject: "No Reply - Message was successful!",
        html: `<div>
            Hello, ${newMessage.fullName} <br /><br />
            Thanks for contacting us!<br /> Our customer support will get back to you as soon as possible.<br /><br />
            Best Regards.<br /><br />
            <b>Global Remit Financial Service Ltd.</b><br />
            <b>Address:</b> 79A West Ham Lane<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Stratford London<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; United Kingdom E15 4PH<br />
            <b>Tel:</b> +233 (0) 203 633 4737<br />
            <b>E-mail:</b> info@globalremitfs.com<br />
            <b>Web Site:</b> https://www.gloremitfs.com
        </div>`
    }

    transporter.sendMail(mailOptions, err => {
        if (err) return res.status(400).json({ message: err.message });
        res.status(200).json({ data: res });
        transporter.sendMail(mailReplyOptions, err => {
            if (err) return res.status(400).json({ message: err.message });
            res.status(200).json({ data: res });
        });
    });

});

module.exports = router;