import React, { Component, Fragment } from 'react';
//import axios from 'axios';
import axios from 'axios-https-proxy-fix';

class ContactUs extends Component {
    constructor() {
        super()
        this.state = {
            fullName: "",
            email: "",
            telephone: "",
            textMessage: ""
        };
        this.onChange = this.onChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }
    
    onChange(e) {
        this.setState({ [e.target.name]: e.target.value });
    }

    onSubmit(e) {
        e.preventDefault();
        const newMessage = {
            fullName: this.state.fullName,
            email: this.state.email,
            telephone: this.state.telephone,
            textMessage: this.state.textMessage
        }
        axios({
            headers: {
                'Content-Type': 'application/json;charset=UTF-8',
                'Access-Control-Allow-Origin': '*'
            },
            proxy: {
                host: 'globalremitfs.com',
                port: 443
            },
            method: 'post',
            url: 'https://globalremitfs.com:8080/contact-us/send',
            data: newMessage
        })
            .then(res => {
                if (res.status === 200) {
                    console.log(res.config.data);
                    alert("Message successfully sent!");
                    this.resetForm();
                } else {
                    alert("Oops! Message not sent. Please, try again.")
                }
            })
            .catch(err => alert(`Error: ${err.message}`));
    }
    
    resetForm() {
        this.setState({
            fullName: "",
            email: "",
            telephone: "",
            textMessage: ""
        });
    }

    render() {
        return (
            <Fragment>
                <div className="section section-presentation">
                    <div className="container">
                        <h4 className="header-text text-center" style={{ marginTop: "80px"}}>Contact Us</h4>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="description">
                                    <div style={{ textAlign: "justify" }}>
                                        <h4>
                                            <span>
                                                <i className="fa fa-phone-square"></i>
                                                &nbsp; &nbsp; +233 (0) 203 633 4737
                                            </span>
                                        </h4>
                                    </div>
                                    <div style={{ textAlign: "justify" }}>
                                        <h4>
                                          <span>
                                                <i className="fa fa-envelope-square"></i>
                                                &nbsp; &nbsp; info@globalremitfs.com
                                            </span>  
                                        </h4>
                                    </div>
                                    <div style={{ textAlign: "justify" }}>
                                        <h4>
                                            <span>
                                                <i className="fa fa-globe"></i>
                                                &nbsp; &nbsp; https://www.gloremitfs.com
                                            </span>
                                        </h4>
                                    </div>
                                    <div style={{ textAlign: "justify" }}>
                                        <h4>
                                            <span>
                                                <i className="fa fa-map-marker"></i>
                                                &nbsp; &nbsp; 79A West Ham Lane<br />
                                                &nbsp; &nbsp; &nbsp; Stratford London <br />
                                                &nbsp; &nbsp; &nbsp; United Kingdom E15 4PH
                                            </span>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-5 col-md-offset-1" style={{ marginTop: "50px" }} >
                                <form className="form-horizontal" onSubmit={this.onSubmit}>
                                    <div className="col-md-12 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input
                                            type="text"
                                            className="form-control has-feedback-left"
                                            placeholder="Full Name"
                                            name="fullName"
                                            value={this.state.fullName}
                                            onChange={this.onChange}
                                            required
                                        />
                                    </div>
                                    <div className="col-md-12 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input
                                            type="email"
                                            className="form-control has-feedback-left"
                                            placeholder="E-mail"
                                            name="email"
                                            value={this.state.email}
                                            onChange={this.onChange}
                                            required
                                        />
                                    </div>
                                    <div className="col-md-12 col-sm-6 col-xs-12 form-group has-feedback">
                                        <input
                                            type="tel"
                                            className="form-control has-feedback-left"
                                            placeholder="Telephone" 
                                            name="telephone"
                                            value={this.state.telephone}
                                            onChange={this.onChange}
                                            required
                                        />
                                    </div>
                                    <div className="col-md-12 col-sm-6 col-xs-12 form-group has-feedback">
                                        <textarea
                                            type="text"
                                            className="form-control has-feedback-left"
                                            rows="10" cols="50"
                                            placeholder="Message"
                                            name="textMessage"
                                            value={this.state.textMessage}
                                            onChange={this.onChange}
                                            required
                                        >
                                        </textarea>
                                    </div>
                                    <div className="form-group">
                                        <div className="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                                            <button type="submit" id="Demo3" className="btn btn-fill btn-info" data-button="info">Send Message</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            
                <div className="section section-testimonial">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="carousel-inner" role="listbox">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2481.601269558655!2d0.0026633157711401885!3d51.53887277964031!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a78b9c382edf%3A0x6826d62a57c57d18!2sGlobalRemit!5e0!3m2!1sen!2sgh!4v1577125857273!5m2!1sen!2sgh" width="1050" height="500" frameBorder="0" style={{ border: "0px"}} allowFullScreen="" title="Google Map"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default ContactUs;
