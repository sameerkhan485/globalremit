import React, { Component, Fragment } from 'react';

class Faq extends Component {
    render() {
        return (
            <Fragment>
                <div className="section section-features">
                    <div className="container">
                        <h4 className="header-text text-center">FAQ</h4>
                        <div className="row">
                            <div className="col-md-12">
                                <div className="card card-blue">
                                    <h4>MoMo Me Frequently Asked Questions</h4><br /><br />
                                    <div style={{ textAlign: "justify" }}>
                                        <ol>
                                            <div style={{textAlign: "center"}}><h3>Know Your Customer(KYC)</h3></div><br />
                                            <li>
                                                <b>What is KYC and why is important?</b><br /><br />
                                                <b>Answer: </b>
                                                KYC means know your customer. It is required by the 
                                                regulators to take ID and Proof of address of all our customers who 
                                                will use our App to send money. This will help us know who we are dealing 
                                                with since it is non face to face transaction.  Having these documents will 
                                                make business relationship strong and lasting.
                                            </li><br />
                                            <li>
                                                <b>What kind of Documents do you require for the KYC checks?</b><br /><br />
                                                <b>Answer:</b>  
                                                To proof your ID, we accept any government issued photo ID. 
                                                (Example Passport, National Identity Cards and Driving Licence.
                                                The documents that you can submit to proof your address include: Bank Statement, 
                                                Utility Bill, Payslip (with your address on).
                                            </li>
                                            <div style={{textAlign: "center"}}><h3>How to Register and Start Sending Money?</h3></div><br />
                                            <li>
                                                <b>How do I register?</b><br /><br />
                                                
                                                    <b>Answer:</b> 
                                                    <ol style={{listStyleType: "lower-alpha"}}>
                                                        <li>Download our App from Google Play store (Android) or App Store (iOS) for free.</li>
                                                        <li>Open the app on your smart phone, click on register to enter your information. </li>
                                                        <li>
                                                            Check your email to vilify your email address, click on profile to enter the rest 
                                                            of the information and send your ID to compliance@globalremitfs.com or Take ID picture with the app.
                                                        </li>
                                                    </ol>
                                            </li><br />
                                            <li>
                                                <b>How do I add or replace a bank card?</b><br /><br />
                                                <b>Answer:</b> 
                                                You can change your card by clicking on Profile and then click on function you will see “edit” 
                                                click on it. Delete the old details and enter the new card details. This card details must be 
                                                under your name.	
                                            </li><br />
                                            <li>
                                                <b>How can I change my ID?</b><br /><br />
                                                <b>Answer:</b> If your ID is expired or you wish to replace the existing one email it to us at 
                                                compliance@globalremitfs.com
                                            </li><br />
                                            <li>
                                                <b>How can I change my personal information?</b><br /><br />
                                                <b>Answer:</b> Log in to the app click on profile and click on the function bottom to change 
                                                any information you wish to change. There are some restriction on certain information you 
                                                cannot change by yourself you have to contact us.
                                            </li><br />
                                            <li>
                                                <b>How can I reset my password?</b><br /><br />
                                                <b>Answer:</b> Open the app and click on forgotten password, you will receive email link to do so. 
                                                Follow the instruction carefully.
                                            </li><br />
                                            <li>
                                                <b>How can I deactivate my account?</b><br /><br />
                                                <b>Answer:</b> You may close your account by contacting our support team support@globalremitfs.com 
                                                We will still hold your transaction records as the regulation requires. 
                                            </li>
                                            <div style={{textAlign: "center"}}><h3>Sending Money</h3></div><br />
                                            <li>
                                                <b>How does MoMo Me work?</b><br /><br />
                                                <b>Answer:</b> After you signed into the app you will be taken straight to <br />
                                                <ol style={{listStyleType: "lower-alpha"}}>
                                                    <li>
                                                        “Select a Valid Service”. Choose from the drop down the service you wish to send eg. 
                                                        “MoMo   Wallet”. 
                                                    </li>
                                                    <li>Next select the “Country”</li>
                                                    <li>
                                                        Enter (or click on the icon to select from your phone contact lists) the beneficiary’s 
                                                        registered wallet number and choose the Mobile Network they are registered with. 
                                                        Eg.  MTN, or AirtelTigo. The app will bring out their registered name. Click “OK” to proceed
                                                    </li>
                                                    <li>
                                                        Enter the amount you wish to send in the calculator and Click on “Send Now”</li>
                                                    <li>Enter your password and click on “Send”</li>
                                                    <li>
                                                        Your Beneficiary will receive the funds into their wallet in seconds (MoMo Wallet Only), 
                                                        if there is an issue and the funds not credited instantly we will notify you through the app 
                                                        as soon as the funds are credited to your beneficiary wallet.
                                                    </li>
                                                </ol>
                                            </li><br />
                                            <li>
                                                <b>What Services do you offer?</b><br /><br />
                                                <b>Answer:</b> Our services include Mobile Wallet transfer, Cash Pick, Bank Account Transfer, 
                                                Airtime TopUp and Card Transfer. 
                                            </li><br />
                                            <li>
                                                <b>Which countries can I send money to?</b><br /><br />
                                                <b>Answer:</b> Currently Ghana, other countries are coming like (Kenya, Uganda, Nigeria)

                                            </li><br />
                                            <li>
                                                <b>Do you charge fees on all of your transfers?</b><br /><br />
                                                <b>Answer:</b> You may not have to pay a fee for sending mobile wallet transaction, 
                                                because we make gains on the exchange rate difference. You may have to pay us the service 
                                                fee if you use Cash Pick, Bank Transfer, Card Transfer, or Airtime TopUp for every transaction 
                                                that you submit, including the transaction amount. The transaction would not be processed 
                                                until you clear the service fee. In addition, during your transaction process, if MoMo Me or 
                                                GlobalRemit becomes responsible for charges extra fee (i.e. The amount excluding the service 
                                                fee and transaction amount), you agree to repay us such extra fee
                                            </li><br />
                                            <li>
                                                <b>How long will it take for the funds to reflect in beneficiary wallet?</b><br /><br />
                                                <b>Answer:</b> Your Beneficiary will receive the funds into their wallet in seconds 
                                                (MoMo Wallet Only), if there is an issue and the funds not credited instantly we will 
                                                notify you through the app as soon as the funds are credited to your beneficiary wallet.
                                            </li><br />
                                            <li>
                                                <b>How do I know the mobile network operator to select?</b><br /><br />
                                                <b>Answer:</b> You will know by the prefix eg. MTN have these prefixes 024, 054, 055. 
                                                AirtelTigo normally have 027,026, 057, 056, Vodafone prefixes 020, and 050). 
                                                Please confirm from your beneficiary.
                                            </li><br />
                                            <li>
                                                <b>How can I cancel a transaction?</b><br /><br />
                                                <b>Answer:</b> You may cancel as long as the transaction is not PROCESSED. 
                                                Contact us to assist you.
                                            </li><br />
                                            <li>
                                                <b>What is the limit I can send in a day?</b><br /><br />
                                                <b>Answer:</b> It all depends on the compliance documents we hold for you. 
                                                The more documents we have for you the more you can send. We will need your ID, 
                                                Proof of address, Bank Statements, Payslip to give you more limit to send.  
                                            </li><br />
                                            <li>
                                                <b>Do I have to request for refund for a failed transaction?</b><br /><br />
                                                <b>Answer:</b> If we are unable to send your transaction to the beneficiary 
                                                wallet we will refund the full amount to your card.
                                            </li><br />
                                            <li>
                                                <b>What is the limit for my Beneficiary?</b><br /><br />
                                                <b>Answer:</b> The beneficiary limits are set by the various Wallet Operators. 
                                                Eg. MTN Ghana has set a limit of 10,000GHS balance per wallet. This means the 
                                                wallet cannot hold funds in excess of this amount. The beneficiary could increase 
                                                this limit subject to submitting further KYC documents to MTN Ghana.  
                                            </li><br />
                                            <li>
                                                <b>Is MoMo Me regulated?</b><br /><br />
                                                <b>Answer:</b> Yes, we are regulated by the FCA and supervise by the HMRC for money laundering.
                                            </li><br />
                                            <li>
                                                <b>Is it safe to use my card to pay for my transactions?</b><br /><br />
                                                <b>Answer:</b> Absolutely safe to use your card. We work partners who take security very serious. 
                                            </li><br />
                                            <li>
                                                <b>Can I use someone’s bank card to pay for my transfer?</b><br /><br />
                                                <b>Answer:</b>  Unfortunately you cannot use any bank card that is not in your own name. 
                                                If you attempt to use someone’s card to pay for your transaction your account will be 
                                                suspended indefinitely. 
                                            </li><br />
                                            <li>
                                                <b>Will my beneficiary be charged fee for cashing out?</b><br /><br />
                                                <b>Answer:</b> MoMo Me mobile wallet transfer is free, however, there is a cash out fee of 
                                                1 to 2 percent of the amount withdrawn by your beneficiary in respective country. 
                                                Eg if your beneficiary is cashing out 100GHS they will be charged 1GHS by MTN Ghana. 
                                            </li><br />
                                            <li>
                                                <b>What about if I want to pay for the cash out charge?</b><br /><br />
                                                <b>Answer:</b> If you want to cover the cash out fee please add 1-2% of received amount. 
                                                Eg if you want them to receive 500GHS and also pay the cash out fee please add 5GHS. 
                                                So you will enter 505 in the receive space of the calculator.
                                            </li><br /><br />
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default Faq;
