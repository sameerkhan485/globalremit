import React, { Component, Fragment } from 'react'

class TermsAndConditions extends Component {
    render() {
        return (
            <Fragment>
                <div className="section section-features">
                    <div className="container">
                        <h4 className="header-text text-center">Terms &amp; Conditions</h4>
                        <div className="row">
                            <div className="col-md-12">
                                <div className="card card-blue">
                                    <h4>Legal Information &amp; Notices</h4><br /><br />
                                    <div style={{textAlign: "justify"}}>
                                        <div>
                                            <ol>
                                                <li>
                                                    These terms and conditions apply to the services received from our Online Mobile App
                                                    customers.  All users of this Mobile App agree that access to and use of this app is
                                                    subject to the following terms and conditions and other applicable law.
                                                    These Terms are only available in the English language and also all services, instructions,
                                                    and communications with clients will be in English ( You may use a third party translation
                                                    system to translate to the appropriate language for your understanding, however, we can not
                                                    be held responsible for any inaccuracies. If you do not agree to these Terms and Conditions,
                                                    please do not access any of our services.
                                                </li>
                                                <li>
                                                    The terms “GlobalRemit FS”, “MoMo Me”, “we”, “us”, and “our” refer to GLOBAL REMIT FINANCIAL
                                                    SERVICES ., a United Kingdom registered company, together with its employees, directors,
                                                    successors, affiliates, and assignees. The company is registered in England and Wales with
                                                    number 9484910 with its registered Head office at 79A West Ham Lane Stratford London E15 4PH.
                                                </li>
                                                <li>
                                                    The terms “you” and “your” refer to users of the Service who creates (“Sender”) or receive
                                                    (“Recipient” or “Beneficiary”) remittances, or user of our mobile app.
                                                </li>
                                                <li>
                                                    Our system is designed to facilitate you send money to your loved ones throughout the world.
                                                    We advise that you don’t send money to someone you know.
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>THE FOLLOWING DEFINITIONS APPLY TO THIS AGREEMENT</b><br /><br />
                                            <ol>
                                                <li>Destination Country refers to the country in which the beneficiary receives money through the Service.</li>
                                                <li>Local Taxes refer to any taxes or charges payable in the Destination Country.</li>
                                                <li>
                                                    Payment Instrument refers to a valid instrument of payment such as a bank account, debit card
                                                    or credit card.
                                                </li>
                                                <li>
                                                    Payout Amount refers to the amount paid out to the Recipient, after any foreign exchange conversion
                                                    and excluding Local Taxes.
                                                </li>
                                                <li>Beneficiary or Receiver or Recipient refers to someone who receives money through the Service.</li>
                                                <li>Sender refers to someone who uses the Service to send money or buy an airtime top up or mobile data..</li>
                                                <li>Service Fee refers to the charges paid to MoMo Me or GlobalRemit FS for the services provided. </li>
                                                <li>
                                                    Service Provider refers to a local bank, money exchange house, agent shop or other third party service
                                                    providers with whom MoMo Me or GlobalRemit FS works with in providing the Service.
                                                </li>
                                                <li>
                                                    Transaction refers to a specific instruction asking MoMo Me or GlobalRemit FS to send money through
                                                     the Service.
                                                </li>
                                                <li>
                                                    Transaction Amount or Principal refers to the amount of money that the Sender wishes to send to the
                                                    Receiver, without any applicable fees and prior to any foreign exchange conversion.
                                                </li>
                                                <li>
                                                    MoMo Me or GlobalRemit FS Online Services refers to money transfer services rendered to customers
                                                    through MoMo Me or GlobalRemit FS mobile app.
                                                </li>
                                                <li>
                                                    MoMo Me or GlobalRemit FS mobile app refers to the mobile app operated by MoMo Me or GlobalRemit
                                                    FS to facilitate the creation of transaction by the customer themselves.
                                                </li>
                                                <li>
                                                    Bank Card  any card issued against a depository account, such as an ATM card or a debit card.
                                                    It also includes credit card issues by banks such as Visa and  Mastercard.
                                                </li>
                                                <li>Card Issuer refers to the issuer and  owner of these  Bank cards.</li>
                                                <li>
                                                    Business Day refers to official working days excluding  Saturday and Sunday and bank
                                                    or public holidays.
                                                </li>
                                                <li>
                                                    Payment Method refers to different options available to the sender  to use in payment
                                                    of his/her selected services and these include, Debit or Credit Card payment, Online Bank
                                                    Transfer.
                                                </li>
                                                <li>
                                                    Mobile App means the application downloaded from the AppStore or PlayStore which enables you
                                                    to create transaction instructions to us.
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>MoMo Me or GlobalRemit RIGHTS AND OBLIGATIONS</b><br /><br />
                                            <ol>
                                                <li>
                                                    By this agreement, MoMo Me or GlobalRemit FS agrees to offer our services to you
                                                    employing duly care and precaution.
                                                </li>
                                                <li>
                                                    Service Availability Restrictions. The Service may not be available in whole or in part
                                                    in countries, and jurisdiction. A valid address is required in all instances.
                                                </li>
                                                <li>
                                                    MoMo Me or GlobalRemit FS reserves the sole right to determine whether or not to accept
                                                    or reject any transaction, request additional information based on our compliance policy.
                                                    However, if we decide not to proceed with your Transaction, we will notify you promptly of
                                                    that decision and refund your money paid to us.
                                                </li>
                                                <li>
                                                    We may decide to modify or discontinue the service or any part of the Service
                                                    without prior notice, at any time.
                                                </li>
                                                <li>
                                                    MoMo Me or GlobalRemit FS may exercise our absolute discretion to refuse any
                                                    Transaction or limit the sending amount. We will decide the amount you can send at
                                                    any point in time based on your previous transactions.
                                                </li>
                                                <li>
                                                    We may, in our sole discretion, refuse Transactions from restricted Senders
                                                    (Please refer to our compliance manual for more details).
                                                </li>
                                                <li>
                                                    We process Transactions promptly, however, any Transaction may be delayed or
                                                    cancelled for a number of reasons, including but not limited to: our efforts
                                                    to verify your identity; to validate your Transaction instructions; to contact
                                                    you; or otherwise to comply with applicable law; or due to variations in
                                                    business hours and currency availability.
                                                </li>
                                                <li>
                                                    We will attempt to assist Senders and Recipients with current information about
                                                    the locations and working hours of our Partners and Payer Institutions by means of
                                                    information on our mobile app. However, you agree that MoMo Me or GlobalRemit shall
                                                    not be held responsible for any inaccuracies that may appear in that information or
                                                    any consequential loss which may result from incorrect or incomplete information.
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>YOUR RIGHTS AND OBLIGATIONS</b><br /><br />
                                            In order to access our service, you have to concur that-<br /><br />

                                            <ol>
                                                <li>
                                                    You should have the legal capacity to form a legal contract with the relevant authority;
                                                    So you have to be at least 18 years old  or above, unless you are not permitted to use our service.
                                                </li>
                                                <li>
                                                    You may not have to pay a fee for sending mobile wallet transaction, because we make gains on the 
                                                    exchange rate difference. You may have to pay us the service fee if you use Cash Pick, Bank Transfer, 
                                                    Card Transfer, or Airtime TopUp for every transaction that you submit, including the transaction 
                                                    amount. The transaction would not be processed until you clear the service fee. In addition, 
                                                    during your transaction process, if MoMo Me or GlobalRemit becomes responsible for charges extra 
                                                    fee (i.e. The amount excluding the service fee and transaction amount), you agree to repay us such 
                                                    extra fee
                                                </li>
                                                <li>
                                                    When you registered on our site to use the service, you have to provide us the following information 
                                                    in accordance with compliance requirements:
                                                </li>
                                                <li>
                                                    The right, exact, present and full evidence of your identity, and  if any changes happen in your 
                                                    personal information., promptly notify us.
                                                </li>
                                                <li>The details of the merchant with one or more Payment gateway.</li>
                                                <li>
                                                    The right, exact, present and full information for all Transactions.
                                                    Please note that,we do not accept any responsibility for damages resulting 
                                                    from non-payment or hindrance in payment of a money transfer to a Recipient or 
                                                    failure to carry out a transaction under the Service by reason of any of these matters.
                                                </li>
                                                <li>
                                                    There will be a difference between the exchange rate when the sender pay for a Transaction 
                                                    in one currency and the Recipient is paid in another currency. MoMo Me or GlobalRemit and its 
                                                    Service Providers usually make a small profit in these circumstances when we buy foreign 
                                                    currency and the exchange rate provided to you.
                                                </li>
                                                <li>
                                                    If any false information is given by you and as a result, if the recipient received the 
                                                    reduced amount for extra charges when the amount is denominated in another currency; we will 
                                                    have no responsibility to make good such reduction.
                                                </li>
                                                <li>
                                                    Once a Transaction has been submitted for processing it is not normally possible to change 
                                                    any of its details. So before the submission, it is your responsibility to make sure all the 
                                                    Transaction details are accurate and you must check the details carefully.
                                                </li>
                                                <li>
                                                        If you face any charges or fees for using  a particular Payment Instrument to fund a Transaction, 
                                                        MoMo Me or GlobalRemit will have no liability  on this issue. These may include, but not limited  
                                                        that the banks may impose fees on you for unauthorised overdraft.It may  also happen for insufficient 
                                                        funds in your bank account or "cash advance" fees and additional interest which may be imposed by 
                                                        credit card providers or they treat use of the Service as a cash transaction rather than a purchase 
                                                        transaction.
                                                </li>
                                                <li>
                                                    You can only use the Service to send money to people that you know personally and not to pay for goods 
                                                    or services. If MoMo Me or GlobalRemit FS reasonably believes you are using the Service to purchase goods 
                                                    or services, we reserve the right to cancel your Transaction(s).
                                                </li>
                                                <li>
                                                    You may not submit or receive a Transaction on behalf of a third person, since,we consider both you 
                                                    and the Recipients will only act on your own behalf. If you plan to submit or receive a Transaction 
                                                    on behalf of a company, business or any entity other than a human individual, you must first inform 
                                                    MoMo Me or GlobalRemit FS of your desire to do so. In this case,you must provide us with any additional 
                                                    information that we request about the entity as we may decide whether to permit the Transaction or not.
                                                </li>
                                                <li>
                                                    When you have access to use our service, you will obey these Terms and Conditions as well as 
                                                    any applicable laws, rules or regulations. It will be considered as  a breach of these Terms 
                                                    and Conditions to use the Service to send money, if we find out-
                                                    <ol style={{listStyleType: "lower-roman"}}>
                                                        <li>The Recipient who has dishonoured the rules of Terms and Conditions.</li>
                                                        <li>
                                                            The Recipient who has a connection with illegal activity,including, without 
                                                            limitation money-laundering, fraud and the funding of terrorist activity. If you use the 
                                                            Service in connection with illegal activity, MoMo Me or GlobalRemit will report you to the 
                                                            appropriate legal authorities.
                                                        </li>
                                                    </ol>
                                                </li>
                                                <li>
                                                    When using our mobile app or the Service or when interacting with MoMo Me or GlobalRemit FS , 
                                                    with another user or with a third party, you will concur that-
                                                </li>
                                                <li>
                                                    You cannot breach these Terms and Conditions, or any other agreement between you and MoMo
                                                    Me or GlobalRemit.
                                                </li>
                                                <li>
                                                    You are NOT ALLOWED to open more than one account, if for any reason you cannot use 
                                                    you registered account contact the support team for assistance and do not  create multiple accounts.
                                                </li>
                                                <li>You will not provide fake, incorrect, or misleading information;</li>
                                                <li>
                                                    You are NOT ALLOWED to permit anyone else access to your registration details, and 
                                                    will keep those details secure.
                                                </li>
                                                <li>You will not use an anonymising proxy (a tool that attempts to make activity undetectable).</li>
                                                <li>
                                                    If in any case, any investigation is carried out, you have to co-operate and  to provide 
                                                    confirmation of any information you provide to us, including proof of identity
                                                </li>
                                                <li>
                                                    You are not allowed to  copy or monitor our mobile app using any robot, spider, or other 
                                                    automatic device, or manual process, without our prior written permission.
                                                </li>
                                                <li>
                                                    MoMo Me or GlobalRemit will store all information required of a Recipient to prove his or 
                                                    her identity or associated with their specific Transaction as  it is necessary to provide 
                                                    the Service,. Such proofs may include a suitable form of valid, unexpired identification 
                                                    from a list of acceptable papers provided by the Service Provider, and/or a Transaction 
                                                    tracking number, a personal identification number (PIN), a "password", a "secret word", 
                                                    or other similar identification sign.
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>CANCELLATIONS AND REFUND  POLICIES</b><br /><br />
                                            <ol>
                                                <li>
                                                    You should contact us  at the following address-<br /><br />
                                                    79A West Ham Lane Stratford London E15 4PH, <br />
                                                    If you face any problems during using the Service. Alternatively, 
                                                    you can contact by email our dedicated online  team via email address below:<br />
                                                    info@globalremitfs.com                                   
                                                </li>
                                                <li>
                                                    You have the legal right to cancel your contract with us after you have submitted 
                                                    a Transaction. In this issue, we may make a cancellation charge. This right of 
                                                    cancellation is valid for fourteen days after you have submitted the transaction, 
                                                    or until we have completed the contract by paying the Payout Amount to the Recipient.
                                                </li>
                                                <li>
                                                    If you want to cancel the transaction, you must submit a written request to us at 
                                                    the address post  or via email on email  address provided. The written request must 
                                                    contain the Sender's full name, address, and phone number, together with the Transaction 
                                                    tracking number, Transaction Amount, and the reason for your refund request.
                                                </li>
                                                <li>
                                                    Any refunds amount will be the same amount as sent amount without the transaction 
                                                    charges or fee and will be credited back to the same Payment Instrument used to 
                                                    fund the Transaction and in the same currency. If any currency fluctuations occur 
                                                    in the event of this cancellation request, no adjustment will be made by us.
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>COMPANY’S POLICIES ON COLLECTION OF INFORMATIONS</b><br /><br />
                                            <ol>
                                                <li>
                                                    Customer Identification Program. According to UK law,it is necessary 
                                                    to provide information about all customers from all financial institutions  
                                                    to the UK Government to assist in the fight against money laundering activities 
                                                    and the funding of terrorism by obtaining, verifying, and recording identifying  
                                                    the information. We may therefore require you to supply us with personal 
                                                    identifying information and we may also officially consult other sources 
                                                    to get information about you.
                                                </li>
                                                <li>
                                                    Verification.By accepting these Terms and Conditions you authorise us to make 
                                                    any inquiries we consider necessary to verify the information that you provide to us. 
                                                    We may do this directly, for instance by requesting you for additional information, 
                                                    requiring you to take steps to confirm ownership of your Payment Instruments or email 
                                                    address; or by confirming your information against third party databases; or through 
                                                    other sources.
                                                </li>
                                                <li>
                                                    Further Authentication and Check. In order to confirm your identity,we will verify 
                                                    your residential address and personal details. We may also pass your personal 
                                                    information to a credit reference agency, which may keep a record of that 
                                                    information. This is done only to confirm your identity.In this matter, no credit 
                                                    check perform on you and your credit rating will be unaffected. All information 
                                                    provided by you will be treated securely and strictly in accordance with the Data 
                                                    Protection Act 1998.
                                                </li>
                                                <li>
                                                    Privacy Policy on Data Utilization.  Under this clause,You permit us to  process 
                                                    your personal information for the purposes of providing the Service, including 
                                                    for verification purposes. You also approve of the use of such data for 
                                                    communicating with you, and for legal, accounting and archival purposes. 
                                                    You acknowledge that you have read and agree with MoMo Me or GlobalRemit FS ’s 
                                                    Data Privacy Policy. 
                                                </li>
                                                <li>
                                                    Government Disclosures. As described in our Data Privacy Policy that we may be 
                                                    required to provide information about you and your Transactions to government by 
                                                    law or other competent authorities.You accept and give permission for us to doing 
                                                    this.
                                                </li>
                                           </ol> 
                                        </div><br /><br />
                                        <div>
                                            <b>INTELLECTUAL PROPERTY RIGHTS</b><br /><br />
                                            <ol>
                                                <li>
                                                    MoMo Me or GlobalRemit FS , their affiliates, or third parties have the entire 
                                                    possession of the MoMo Me or GlobalRemit FS mobile app and the MoMo Me or 
                                                    GlobalRemit FS Service, the content, and all intellectual property relating 
                                                    to them and contained in them (including but not limited to copyrights, 
                                                    patents, database rights, trademarks and service marks). 
                                                    All rights, label and interest in and to the MoMo Me or GlobalRemit FS  
                                                    Online Site and its Service shall remain our property and/or the property 
                                                    of our  business partners.
                                                </li>
                                                <li>
                                                    You may use MoMo Me or GlobalRemit FS ’s site and services only for the 
                                                    purposes allowed by these Terms and Conditions or described on this mobile app. 
                                                    For your own personal use, you are authorized to view and to keep a copy of the 
                                                    pages of the MoMo Me or GlobalRemit FS ’s mobile app.  You also have to agree 
                                                    that-
                                                    <ol style={{listStyleType: "lower-roman"}}>
                                                        <li>
                                                            You are not allowed to make any duplicates of any part of any materials, 
                                                            or remove or change anything on the site, include or create links to or from the 
                                                            site without the company’s written authority.
                                                        </li>
                                                        <li>
                                                            You are also not allowed to remove or change any copyright, trademark or other 
                                                            intellectual property rights notices contained in any materials or copies or the 
                                                            materials.
                                                        </li>
                                                        <li>
                                                            You are not permitted to participate in the transfer or sale of, post on the 
                                                            internet, or in any way distribute or exploit the MoMo Me or GlobalRemit FS 
                                                            mobile app, the MoMo Me or GlobalRemit FS Service or any portion thereof for 
                                                            any public or commercial use without our express written permission.
                                                        </li>
                                                        <li>
                                                            You cannot use any robot, spider, scraper or other automated device to access 
                                                            the MoMo Me or GlobalRemit FS mobile app and its service.
                                                        </li>
                                                    </ol>
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>WARRANTIES AND  COMPANY’S LIABILITY</b><br /><br />
                                            <ol>
                                                <li>
                                                    If your money transfer has failed in such circumstances, for example, any breach
                                                    of our agreement with you, We will refund to you any benefit that we receive
                                                    (this means that, we will refund to you the Transaction Amount and the Service Fee).
                                                </li>
                                                <li>
                                                    Under  the laws relating to the provision of international money transfer services, 
                                                    if a money transfer is delayed or fails, you may have a right to receive a refund or 
                                                    compensation. If you want to know the details of your rights to a refund or compensation, 
                                                    please contact us at the address that we have given at the end of these terms & conditions.
                                                </li>
                                                <li>
                                                    If you or recipient claims for compensation from us, that (claim(s)) must be supported by 
                                                    any available relevant documentation(s).
                                                </li>
                                                <li>
                                                    We do not accept any liability for the following issues-
                                                    <ol style={{listStyleType: "lower-roman"}}>
                                                        <li>
                                                            If any failure happens to perform your instructions in consequence of
                                                            circumstances that could reasonably be considered to be outside our control.
                                                        </li>
                                                        <li>
                                                            In  case of communications malfunction which cannot reasonably be considered 
                                                            to be under our control and that may affect the accuracy or timeliness of 
                                                            messages you send to us.
                                                        </li>
                                                        <li>
                                                            If any losses or delays in transmission of messages caused because of the use 
                                                            of any internet service provider or caused by any browser or other software which 
                                                            is not under our control;
                                                        </li>
                                                        <li>
                                                            Any mistake on the mobile app or with the Service caused by incomplete or incorrect 
                                                            information provided to us by you or a third party.
                                                        </li>
                                                    </ol>
                                                </li>
                                                <li>
                                                    We take the liability in the special case (a) on our part for death or personal 
                                                    injury resulting from our negligence; or (b) exclude liability for our fraud.
                                                </li>
                                                <li>
                                                    You agree that the rules are applied both on you and your recipient.
                                                </li>
                                                <li>
                                                    Your contract is with MoMo Me or GlobalRemit FS only. You agree that 
                                                    no affiliate or agent of MoMo Me or GlobalRemit FS owes you any duty of care 
                                                    when performing a task which would otherwise have to be performed by MoMo Me or 
                                                    GlobalRemit FS  under its agreement with you.
                                                </li>
                                                <li>
                                                    You agree to assure and hold harmless MoMo Me or GlobalRemit FS, our 
                                                    subsidiaries, affiliates, officers, directors, employees, agents, independent 
                                                    contractors, advertisers, partners, and co-branders from all loss, damage, 
                                                    claims, actions or demands, including reasonable legal fees, arising out of 
                                                    your use or misuse of this mobile app or Service, all activities that occur 
                                                    under your password or account e- mail login, your breach of these Terms and 
                                                    Conditions or any other violation of the rights of another person or party.
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>ELECTRONIC COMMUNICATIONS POLICIES</b><br /><br />
                                            <ol>
                                                <li>
                                                    You accept that these Terms and Conditions will be entered into electronically,
                                                    and the following categories of information (i.e.Communications) may be provided
                                                    by electronic means:
                                                    <ol style={{listStyleType: "lower-roman"}}>
                                                        <li>
                                                            Thess Terms and Conditions and any adjustments, modifications or supplements 
                                                            to it.
                                                        </li>
                                                        <li>Your records of transactions via the Service.</li>
                                                        <li>Any other communication connected to the Service or MoMo Me or GlobalRemit FS .</li>
                                                        <li>
                                                            Any service  related to communications that  includes without limitation  of
                                                            communications with respect to claims of error or unauthorised use of the Service.</li>
                                                        <li>
                                                            Any disclosures or notice (initial/ periodic) provided in connection with the Service,
                                                            including without limitation those obligatory by law.
                                                        </li>
                                                    </ol>
                                                </li>

                                                <li>
                                                    The Service does not permit for Communications through in paper format or through 
                                                    other non-electronic means. You may withdraw your consent to receive Communications 
                                                    electronically, but if you do, your use of the Service shall be terminated. If you want to withdraw your consent, you must contact us through our contact address.
</li>
                                                <li>
                                                    If you want to access and retain Communications, you must have the following supports:
                                                    <ol style={{listStyleType: "lower-roman"}}>
                                                        <li>
                                                            An Internet browser that supports 128-bit encryption, such as Internet Explorer 
                                                            version 4.0 or above;
                                                        </li>
                                                        <li>
                                                            An e-mail account and e-mail software capable of interfacing with MoMo Me or 
                                                            GlobalRemit FS 's e-mail servers;
                                                        </li>
                                                        <li>
                                                            A personal computer, operating system and telecommunications connections to 
                                                            the Internet capable of supporting the foregoing;
                                                        </li>
                                                        <li>
                                                            Sufficient electronic storage capacity on your computer's hard drive or other 
                                                            data storage unit; and
                                                        </li>
                                                        <li>
                                                            A printer that is capable of printing from your browser and e-mail software. 
                                                            Furthermore, you must update us without delay if any changes happen to your email 
                                                            address by updating your profile at ....................
                                                        </li>
                                                    </ol>
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>DISCONTINUATION</b><br /><br />
                                            <ol>
                                                <li>
                                                    Either party could terminate these Terms and Conditions on one day's 
                                                    written notice.
                                                </li>
                                                <li>
                                                    We may discontinue these Terms and Conditions if you have such circumstances:
                                                    <ol style={{listStyleType: "lower-roman"}}>
                                                        <li>If you are declared as bankrupt.</li>
                                                        <li>If you attempt to violate of any provision of this Terms and Conditions;</li>
                                                        <li>
                                                            If your way of use of the Service or the mobile app is disruptive to our 
                                                            other customers, or you do anything which in our opinion is likely to bring us 
                                                            into disrepute;
                                                        </li>
                                                        <li>
                                                            Any  attempt to breach the security of the mobile app (including but not 
                                                            limited to: modifying or attempting to modify any information; unauthorised 
                                                            log-ins, unauthorised data access or deletion; interfering with the service, 
                                                            system, host or network; reverse engineering of any kind; spamming; hacking; 
                                                            falsifying data; introducing viruses, Trojan horses, worms or other destructive 
                                                            or damaging programs or engines; or testing security in any way).
                                                        </li>
                                                    </ol>
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>PURCHASE</b><br /><br />
                                            Before you create any transaction on our mobile app you agree that you represent 
                                            and warrant that: firstly, you have the legal right to use any account/credit/debit 
                                            card(s) or other payment method(s) in connection with any transaction; and secondly, 
                                            that the details you provide to us are true, accurate and complete. By supplying such 
                                            details, you grant us the full right to submit the details to third parties for purposes 
                                            of assisting the completion of transaction.
                                            If you create any transaction made available through our mobile app (“Purchase”), 
                                            you may be asked to provide certain details of the recipient in order to complete the 
                                            purchase. These include but not limited to the following: <br /><br />
                                            <div>
                                                <b>Cash Collection Transaction:</b><br /><br />
                                                <ul>
                                                    <li>Full name of the Beneficiary as it shows in their ID</li>
                                                    <li>Address of the beneficiary,  town or city</li>
                                                    <li>Beneficiary mobile number.</li>
                                                </ul>
                                            </div><br /><br />
                                            <div>
                                                <b>Bank Account Credit Transaction:</b><br /><br />
                                                <ul>
                                                    <li>Bank name</li>
                                                    <li>Account Name</li>
                                                    <li>Account number</li>
                                                    <li>Bank Branch /Sort Code</li>
                                                    <li>IBAN</li>
                                                    <li>BIC/SWIFT</li>
                                                    <li>Type of Account</li>
                                                </ul>
                                            </div><br /><br />
                                            <div>
                                                <b>Mobile Money:</b><br /><br />
                                                The registered mobile money account number

                                            </div><br /><br />
                                            <div>
                                                <b>Airtime or Data Top up</b><br /><br />
                                                The beneficiary mobile
                                            </div><br /><br />
                                            <div>
                                                <b>Home Delivery Service</b><br /><br />
                                                <ul>
                                                    <li>Beneficiary full name</li>
                                                    <li>Address for delivery</li>
                                                </ul>
                                            </div><br /><br />
                                            <ol style={{listStyleType: "lower-roman"}}>
                                                <li>
                                                    By using our Services, you agree to authorised MoMo Me or GlobalRemit FS’s 
                                                    Application to debit your account or bank card with the principal value of the 
                                                    transaction plus other applicable fees and charges.
                                                </li>
                                                <li>
                                                    You acknowledge that MoMo Me or GlobalRemit FS shall not process or complete 
                                                    your transaction if payment request to your payment account is unsuccessful for 
                                                    any reason. Your bank or financial institution may charge you for going over your 
                                                    account limit. You must ensure you have sufficient funds in your account or card 
                                                    before you initiate the request. 
                                                </li>
                                                <li>
                                                    MoMo Me or GlobalRemit FS will make the necessary effort to display currency exchange 
                                                    rate, any fees and service charges in the mobile App before you complete your transaction 
                                                    request. Note that our services charges change depending on the location and from time 
                                                    to time. MoMo Me or GlobalRemit FS also earns profit from the exchange rate. 
                                                </li>
                                                <li>
                                                    In a situation where MoMo Me or GlobalRemit FS is unable to debit your payment 
                                                    card or is returned, charged back or probably cancelled for whatever reason and 
                                                    the order is paid out, you agree entirely to be responsible to settle the full 
                                                    amount due plus any other costs incurred by MoMo Me or GlobalRemit FS to deliver 
                                                    the service to your beneficiary. 
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>SERVICES</b><br /><br />
                                            <ol>
                                                <li>
                                                    Cash Pick Up/Collection Transaction is a transaction created either online or on 
                                                    our agency platform and the beneficiary picks cash from the bank or payout location 
                                                    in the destination country.</li>
                                                <li>
                                                    You agree that, when you register and create a transaction we have the right to 
                                                    verify your ID details, address and payment details before the transaction will be 
                                                    ready for collection at the destination country. </li>
                                                <li>
                                                    During verification your transaction may not be ready for pick up, We reserve 
                                                    the right to cancel the transaction if our responsible teams are not 
                                                    satisfied with your details.
                                                </li>
                                                <li>
                                                    Where there are delays in payout and the exchange rate changes MoMo Me or 
                                                    GlobalRemit FS  shall not be responsible for any losses. </li>
                                                <li>MoMo Me or GlobalRemit FS takes no responsibility in destination country restrictions. </li>
                                                <li>
                                                    Mobile Money/Wallet Number. When you enter a wrong mobile money number during your transaction 
                                                    request creation, we will not be liable to refund your mobile since we do not have control over the 
                                                    wallet number that the funds have been credited.
                                                </li>
                                                <li>
                                                    Some countries have taxes or charges on receiving mobile money fund which your beneficiary 
                                                    may receive lower amount that what will be on your receipt. 
                                                </li>
                                            </ol>
                                        </div><br /><br />
                                        <div>
                                            <b>SECURITY ISSUE</b><br /><br />
                                            We take security  matters very seriously at MoMo Me or GlobalRemit FS , 
                                            and we give our effort  really hard, using state-of-the-art security measures 
                                            in order to make sure that your information is maintained  in a secure way. 
                                            The MoMo Me or GlobalRemit FS  online services is a protected and convenient way 
                                            to send money to friends and family and to other people who you trust. However, 
                                            we do advise you to consider very carefully before sending money to anyone that 
                                            you do not know well. In particular, you should be very cautious of deals or offers 
                                            that seem too good to be true(for avoiding being scammed). If you are aware of anyone 
                                            or any entity that is using the Our Online  Service improperly, please email us using 
                                            our contact form. Likewise, if you receive any emails, pretending to be from MoMo Me 
                                            or GlobalRemit FS , which you suspect may be " fake emails, please forward them to us 
                                            using our provided  contact options via post or email. 
                                        </div><br /><br />
                                        <div>
                                            <b>Contact Information</b><br /><br />
                                            If you want to make a complaint about any aspect of the MoMo Me or GlobalRemit FS  
                                            Online Services , or you have any questions, notices, and requests for refunds or 
                                            further information should be sent to the address shown on the Contact Us page-
                                            <b>79A West Ham Lane Stratford London E15 4PH,</b>
                                            or email us on <b>info@globalremitfs.com</b>
                                            In case of any complaint,We will investigate it and come back to you with the results 
                                            of our investigation, no later than 7 business days of receipt of your complaint. 
                                            If you are not satisfied with the manner in which we have dealt with your complaint, 
                                            or the outcome, then you may refer the matter to the Financial Ombudsman Service, 
                                            South Quay Plaza, 183 Marsh Wall, London E14 9SR.
                                            We are committed to give our clients the highest service and we hope that you will 
                                            be pleased with the way we treat the monetary agreement.
                                        </div><br /><br />
                                    </div>  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default TermsAndConditions;
