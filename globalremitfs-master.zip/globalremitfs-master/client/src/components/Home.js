import React, { Component, Fragment } from 'react';
import { Link } from 'react-router-dom';

class Home extends Component {
    render() {
        return (
            <Fragment>
                <div className="parallax filter-gradient blue" data-color="blue">
                    <div className="parallax-background">
                        <img className="parallax-background-image" src={"assets/img/bg3.jpg"} alt="" />
                    </div>
                    <div className= "container">
                        <div className="row">
                            <div className="col-md-5 hidden-xs">
                                <div className="parallax-image">
                                    <img className="phone" src={"assets/img/iphone3.png"} style={{ marginTop: "20px" }} alt="" />
                                </div>
                            </div>
                            <div className="col-md-6 col-md-offset-1">
                                <div className="description">
                                    <h2><b>Free Money Transfer <br />Is Here ...</b></h2>
                                    <br />
                                    <h4>
                                        Paying fee to send money, is a thing of the past. 
                                    </h4>
                                </div>
                                <div className="buttons">
                                    <button className="btn btn-simple btn-neutral">
                                        <Link to="/about-us"><img src={"assets/img/app-store.png"} alt="" /></Link>
                                    </button>
                                    <button className="btn btn-simple btn-neutral">
                                        <Link to="/contact-us"><img src={"assets/img/play-store.png"} alt="" /></Link>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="section section-features">
                    <div className="container">
                        <h4 className="header-text text-center">Features</h4>
                        <div className="row">
                            <div className="col-md-4">
                                <div className="card card-blue">
                                    <div className="icon">
                                        <i className="pe-7s-cash"></i>
                                    </div>
                                    <div className="text">
                                        <h4>No Fee</h4>
                                        <p>
                                            <b>We pride ourselves with our "No Fee" service. At anytime and any amount you send..., it's still no fee.</b>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="card card-blue">
                                    <div className="icon">
                                        <i className="pe-7s-graph1"></i>
                                    </div>
                                    <h4>High Rate</h4>
                                    <p>
                                        <b>It's our priority to keep the rate as high as possible... That means making your loved ones receive more.</b>
                                    </p>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="card card-blue">
                                    <div className="icon">
                                        <i className="pe-7s-clock"></i>
                                    </div>
                                    <h4>Fast &amp; Reliable</h4>
                                    <p>
                                        <b>Everyday, we make you and your loved ones happy. As soon as you transfer the money, they receive it.</b>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/*
                <div className="section section-demo">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-6">
                                <div id="description-carousel" className="carousel fade" data-ride="carousel">
                                    <div className="carousel-inner">
                                        <div className="item">
                                            <img src={"assets/img/home_33.jpg"} alt="" />
                                        </div>
                                        <div className="item active">
                                            <img src={"assets/img/home_22.jpg"} alt="" />
                                        </div>
                                        <div className="item">
                                            <img src={"assets/img/home_11.jpg"} alt="" />
                                        </div>
                                    </div>
                                    <ol className="carousel-indicators carousel-indicators-blue">
                                        <li data-target="#description-carousel" data-slide-to="0" className=""></li>
                                        <li data-target="#description-carousel" data-slide-to="1" className="active"></li>
                                        <li data-target="#description-carousel" data-slide-to="2" className=""></li>
                                    </ol>
                                </div>
                            </div>
                            <div className="col-md-5 col-md-offset-1">
                                <h4 className="header-text">MoMo Me</h4>
                                <p style={{ textAlign: "justify" }}>
                                    Over a decade in the financial industry, we offer to our happy customers the best of the payment services.
                                    From <b>No Fee</b> to <b>High Rate</b>, our hallmark is more than just a fast and secure money
                                    transfer service.
                                </p>
                                <Link to="/about-us" id="Demo3" className="btn btn-fill btn-info" data-button="info">Read More</Link>
                            </div>
                        </div>
                    </div>
                </div>
                */}
                {/*
                <div className="section section-presentation">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-6">
                                <div className="description">
                                    <h4 className="header-text">Money Transfer</h4>
                                    <p style={{ textAlign: "justify" }}>
                                        Electronic funds transfer or EFT are electronic transfer of money from one bank account to another, 
                                        either within a single financial institution or across multiple institutions, via computer-based systems, 
                                        without the direct intervention of bank staff. 
                                    </p>
                                    <p style={{ textAlign: "justify" }}>
                                        We as a financial service provider understand better the need in the financial industry, and make sure transferring
                                        money from one point to another point of the globe becomes more easier and faster at no cost.
                                        From one bank account to another or from bank account to mobile wallet and vice-versa, there is no doubt about the future.
                                        And the future is now.
                                    </p>
                                </div>
                            </div>
                            <div className="col-md-5 col-md-offset-1 hidden-xs">
                                <img src={"assets/img/mac.png" } alt="" />
                            </div>
                        </div>
                    </div>
                </div>
                */}
                <div className="section section-no-padding">
                    <div className="parallax filter-gradient blue" data-color="blue">
                        <div className="parallax-background">
                            <img className ="parallax-background-image" src="assets/img/bg2.jpg" alt="" />
                        </div>
                        <div className="info">
                            <h1>Free &amp; High Rate Money Transfer</h1>
                            <h2>Send money instantly to your loved ones at anytime!</h2>
                                <Link to="/"  className="btn btn-neutral btn-lg btn-fill">How to do it?</Link>
                        </div>
                    </div>
                </div>
                <div className="section section-testimonial">
                    <div className="container">
                        <h4 className="header-text text-center">What people say</h4>
                        <div id="carousel-example-generic" className="carousel fade" data-ride="carousel">
                            {/* Wrapper for slides */}
                            <div className="carousel-inner" role="listbox">
                                <div className="item">
                                    <div className="mask">
                                        <img src={"assets/img/face-4.jpg"} alt="" />
                                    </div>
                                    <div className="carousel-testimonial-caption">
                                        <p>Serwaa Amihere, Journalist</p>
                                        <h3>"I just wanted to give it a try and then I failed in love with their <i>no fee</i> and <i>high rate</i> services!"</h3>
                                    </div>
                                </div>
                                <div className="item active">
                                    <div className="mask">
                                        <img src={"assets/img/face-3.jpg"} alt="" />
                                    </div>
                                    <div className="carousel-testimonial-caption">
                                        <p>John Simpson, Investor</p>
                                        <h3>"Really great service and professional team! My friend received the transfer in less than a minute."</h3>
                                    </div>
                                </div>
                                <div className="item">
                                    <div className="mask">
                                        <img src={"assets/img/face-2.jpg"} alt="" />
                                    </div>
                                    <div className="carousel-testimonial-caption">
                                        <p>Sonya Fox, Entrepreneur</p>
                                        <h3>"Exactly the money transfer service I needed. No fee, simple and reliable!"</h3>
                                    </div>
                                </div>
                            </div>
                            <ol className="carousel-indicators carousel-indicators-blue">
                                <li data-target="#carousel-example-generic" data-slide-to="0" className="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default Home;
