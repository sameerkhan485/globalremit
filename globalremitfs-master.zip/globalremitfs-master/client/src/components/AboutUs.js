import React, { Component, Fragment } from 'react';

class AboutUs extends Component {
    render() {
        return (
            <Fragment>
                <div className="section section-features">
                    <div className="container">
                        <h4 className="header-text text-center">About Us</h4>
                        <div className="row">
                            <div className="col-md-12">
                                <div className="card card-blue">
                                    <div style={{textAlign: "justify"}}> <br /><br />
                                        <p>
                                            MoMo Me is the trading name of Global Remit Financial Services Ltd 
                                            literally meaning “send me mobile money”. <br />MoMo Me is about delivering 
                                            instant money transfer services to beneficiaries 24/7.
                                        </p> 
                                        <p>
                                            We believe sending your hard earned money shouldn’t be another hard work 
                                            so we have developed a solid mobile App to make sending money seamlessly and 
                                            joyful. 
                                            We understand how technology is moving so fast that’s why we have combined experience 
                                            and skills to build a backend system to do all the hard work.
                                            Technology is our backbone so we have engaged high profile engineers to oversee our 
                                            systems all the time. We are bold to say that we have slashed the exorbitant fees 
                                            paid for sending money to your family and friends in Africa.
                                        </p>
                                        
                                    </div>  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default AboutUs;
