import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Navbar extends Component {
    render() {
        return (
            <nav className="navbar navbar-transparent navbar-top" role="navigation">
                <div className="container">
                    {/* Brand and toggle get grouped for better mobile display */}
                    <div className="navbar-header">
                        <button id="menu-toggle" type="button" className="navbar-toggle" data-toggle="collapse" data-target="#example">
                        <span className="sr-only">Toggle navigation</span>
                        <span className="icon-bar bar1"></span>
                        <span className="icon-bar bar2"></span>
                        <span className="icon-bar bar3"></span>
                        </button>
                        <Link to="/">
                            <div className="logo-container">
                                <div className="logo">
                                    <img src={"assets/img/new_logo.jpg"} alt="MoMoMe" />
                                </div>
                                <div className="brand">{/* Project Name */}</div>
                            </div>
                        </Link>
                    </div>
                        {/* Collect the nav links, forms, and other content for toggling */}
                    <div className="collapse navbar-collapse" id="example" >
                        <ul className="nav navbar-nav navbar-right">
                            <li>
                                <Link to="/about-us">About Us</Link>  
                            </li>
                            <li>
                                <Link to="/faq">FAQ</Link>
                            </li>
                            <li>
                                <Link to="/contact-us">Contact Us</Link>
                            </li>
                        </ul>
                    </div>
                    {/*  /.navbar-collapse */}
                </div>
            </nav>
        )
    }
}

export default Navbar;
