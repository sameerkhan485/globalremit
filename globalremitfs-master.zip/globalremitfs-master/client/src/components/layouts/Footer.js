import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Footer extends Component {
    render() {
        return (
            <footer className="footer">
                <div className="container">
                    <nav className="pull-left">
                        <ul>
                            <li>
                                <Link to="/privacy-policy">Privacy Policy</Link>
                            </li>
                            <li>
                                <Link to="/terms-and-conditions">Terms &amp; Conditions</Link>
                            </li>
                        </ul>
                    </nav>
                    
                    <div className="social-area pull-right">
                        <Link className="btn btn-social btn-facebook btn-simple" to="#">
                            <i className="fa fa-facebook-square"></i>
                        </Link>
                        <Link className="btn btn-social btn-twitter btn-simple" to="#">
                            <i className="fa fa-twitter"></i>
                        </Link>
                        <Link className="btn btn-social btn-pinterest btn-simple" to="#">
                            <i className="fa fa-pinterest"></i>
                        </Link>
                    </div>
                    <div className="copyright">
                        Copyright &copy; {new Date().getFullYear()} <Link to="/">Global Remit Financial Service Ltd</Link> &ndash; All rights reserved.<br />
                        Designed By <Link to="https://unitedfintech.net">United Fintech Ltd</Link>
                    </div>
                </div>
            </footer>
        )
    }
}

export default Footer;
