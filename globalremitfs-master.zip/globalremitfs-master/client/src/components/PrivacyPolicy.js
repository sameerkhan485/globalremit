import React, { Component, Fragment } from 'react';

class PrivacyPolicy extends Component {
    render() {
        return (
            <Fragment>
                <div className="section section-features">
                    <div className="container">
                        <h4 className="header-text text-center">Privacy Policy</h4>
                        <div className="row">
                            
                            <div className="col-md-12">
                                <div className="card card-blue">
                                    <h4>The MoMo Me Privacy Policy was updated on August 29, 2019.</h4><br /><br />
                                    <div style={{textAlign: "justify"}}>
                                        <div>
                                            MoMo Me takes the responsibility in protecting the personal information it 
                                            collects from its customers that access or use this mobile app situated at www.gloremit.com. 
                                            By accessing www.gloremit.com users agree to be bound by the privacy policy effective at the 
                                            time of using the site. This privacy policy is part of the MoMo Me mobile app terms and conditions. 
                                            MoMo Me reserves the right in its sole discretion to make amendments to this privacy policy at any 
                                            time. In the event of changes, MoMo Me will publish the amended policy. Every time a user accesses 
                                            www.gloremit.com that user agrees to be bound by all the policies posted on the mobile app at that 
                                            particular time. MoMo Me will take all practical steps to use or disclose users’ personal data only 
                                            in the manner permitted by this policy.<br /><br />
                                        </div>
                                        <div>
                                            <b>Personal Information</b><br /><br />
                                            Personal information refers to all private information about an identifiable individual, such as user’s 
                                            name, contact details, identity documents and age.<br /><br />
                                        </div>
                                        <div>
                                            <b>Active Collection of Personal Information</b><br /><br />
                                            The MoMo Me mobile app actively collects information from users by requesting personal details on 
                                            registration. Some areas of this site may also require the user to submit information in order for the 
                                            user to be registered for certain additional services or benefit from specified features (For example 
                                            newsletter subscriptions or payment processing) or to participate in a particular activity (such as 
                                            competitions or promotions). In these situations, gloremit.com will ask the user for particular information, 
                                            and inform the user at each information point what information is required and what information is optional.<br /><br />
                                        </div>
                                        
                                        <div>
                                            <b>Passive Collection of Personal Information</b><br /><br />
                                            MoMo Me passively collects (i.e. without the user actively providing the information) personal information about 
                                            a user as the user accesses and navigates through the gloremit.com mobile app using various technologies and means, 
                                            such as navigational data collection and cookies. MoMo Me uses cookies to make sure user’s sessions on the MoMo Me 
                                            mobile app are secure. MoMo Me also uses embedded pixels – with cookies, these help to track how many people are using
                                            the site. These collect data about the paths that users take when navigating the MoMo Me mobile app. We use this 
                                            information to evaluate site content, navigability and composition, as well as page response rates 
                                            (how quickly pages download). With both cookies and embedded pixel technology, the information MoMo Me collects 
                                            is anonymous and does not contain users’ names, address, telephone numbers, or email addresses.<br /><br />
                                            Please note that users may disable the use of cookies by configuring the user’s browser accordingly. 
                                            Visitors to this mobile app who have JavaScript enabled are tracked using Google Analytics. 
                                            Google Analytics collects the following types of information from users:<br /><br />
                                            
                                            <ol>
                                                <li>Type of user agent (web browser) used software manufacture and version number.</li>
                                                <li>Type of operating system</li>
                                                <li>Screen colours (colour processing ability of the users screen)</li>
                                                <li>JavaScript support</li>
                                                <li>Flash version</li>
                                                <li>Screen resolution</li>
                                                <li>Network location and IP address</li>
                                                <li>Can include country, city, state, region, county, or any other geographic data.</li>
                                                <li>Hostname</li>
                                                <li>Bandwidth (internet connection speed)</li>
                                                <li>Time of visit</li>
                                                <li>Pages visited</li>
                                                <li>Time spent on each page of the mobile app</li>
                                                <li>Referring site statistics</li>
                                                <li>
                                                    The mobile app the user came through in order to arrive at this mobile app
                                                    (example: clicking on a hyperlink from Yahoo.com that took the user to this mobile app)
                                                </li>
                                                <li>
                                                    Search engine query used (example: typing in a phrase into a search engine like Google, 
                                                    and clicking on a link from that search engine)
                                                </li>
                                            </ol>  
                                        </div>
                                        <div>
                                            This data is primarily used to optimize our mobile app for our visitors; however we will use this 
                                            data for marketing purposes. An example of how this data could be used for marketing purposes 
                                            would be to tell potential advertiser show many visitors we get to the mobile app, where our 
                                            visitors come from, and how they arrive at our mobile app. This data DOES NOT include any 
                                            personalized identification information such as:<br /><br />
                                            <ol>
                                                <li>Names</li>
                                                <li>Phone Numbers</li>
                                                <li>Email Addresses</li>
                                                <li>Mailing Addresses</li>
                                                <li>Social Security Numbers</li>
                                                <li>Bank Account Numbers</li>
                                                <li>Credit Card Information</li>
                                            </ol>
                                        </div>
                                        <div>
                                            Consent to Collection, Use and Storage of User’s Personal Information
                                            The user agrees that gloremit.com may collect, use and store the user’s personal information<br /><br />
                                            <ul>
                                                <li>to establish and verify a user’s identity;</li>
                                                <li>to maintain and update gloremit.com customer, or potential customer, databases;</li>
                                                <li>to greet the user when he/she accesses the mobile app;</li>
                                                <li>to provide the user with value added services;</li>
                                                <li>to communicate with the user;</li>
                                                <li>to customise the gloremit.com mobile app to users’ preferences;</li>
                                                <li>to inform the user of facts relating to his/her access to and use of the gloremit.com mobile app;</li>
                                                <li>to improve the content of the gloremit.com mobile app or any of the services provided by MoMo Me;</li>
                                                <li>to inform the user about MoMo Me services, including information of particular relevance to that user;</li>
                                                <li>to inform the user about competitions, promotions and special offers from MoMo Me;</li>
                                                <li>for marketing, product research and development purposes of gloremit.com;</li>
                                                <li>
                                                    to provide the user with targeted advertising when he/she accesses the MoMo Me mobile app or
                                                    other mobile apps of MoMo Me; and
                                                </li>
                                                <li>
                                                    to compile, use, disclose and trade with, non-personal statistical information about browsing habits,
                                                    click-patterns, user preferences and access to the MoMo Me mobile app.<br /><br />
                                                </li>
                                            </ul>
                                        </div>
                                        <div>
                                            <b>Disclosure of User’s Personal Information</b><br /><br />
                                            MoMo Me will not disclose, for commercial gain or otherwise, users’ personal information other than set 
                                            out in this policy. The user agrees that MoMo Me may disclose the user’s personal information:<br /><br />
                                            <ol>
                                                <li>to MoMo Me affiliates;</li>
                                                <li>
                                                    to third partied contracted or employed by MoMo Me to provide services for or to MoMo Me,
                                                    including for example, mobile app hosting and development, technical support, financial services 
                                                    such as processing of credit card or other payments, delivery services, and other support services. 
                                                    These companies require access to users’ personal information to perform their function and not for 
                                                    any other purposes and MoMo Me will take all reasonable steps to enter into confidentiality and
                                                    non-disclosure agreements with the relevant service providers;
                                                </li>
                                                <li>
                                                    to any third party who acquires all, or substantially all, of the assets or shares of MoMo Me,
                                                    any of MoMo Me affiliates, and/or the gloremit.com mobile app, whether by sale, merger, acquisition
                                                    or otherwise;
                                                </li>
                                                <li>
                                                    to governmental agencies, exchanges and other regulatory or self regulatory bodies if MoMo Me
                                                    is required to do so by law or if MoMo Me  believes that such action is necessary
                                                </li>
                                                <li>to comply with the law or with any legal process;</li>
                                                <li>Protect and defend the rights, property or safety of MoMo Me, its affiliates or their customers;</li>
                                                <li>
                                                    Prevent or deal with fraud or the abuse, misuse or unauthorised use of the gloremit.com mobile app;
                                                    and/or protect the rights, property or safety of members of the public (if a user provides false or
                                                    deceptive information about him/herself or misrepresents him/herself as being someone else, MoMo Me
                                                    will proactively disclose such information to the appropriate regulatory bodies and commercial entities)
                                                </li>
                                                <li>
                                                    The user agrees that MoMo Me may use the user’s personal information to compile profiles for statistical
                                                    purposes and may freely trade with such profiles and statistical data, provided that the profiles or
                                                    statistical data cannot be linked to the user by a third party.
                                                </li>
                                                <li>
                                                    In order to ensure that a user’s personal information is accurate, current and complete,
                                                    the user may contact MoMo Me at: <br />
                                                    <span className="tab-space">Email: info@globalremitfs.com</span><br />
                                                    <span className="tab-space">Telephone: +44 (0)208 1271742</span> <br />
                                                    MoMo Me will take reasonable steps to correct or update information.<br /><br />
                                                </li>
                                            </ol>
                                        </div>
                                        <div>
                                            <b>To Unsubscribe</b><br />
                                            Should a user not wish to receive electronic communications from MoMo Me , the user may unsubscribe 
                                            on the mobile app or contact the call centre on <br />
                                            <span className="tab-space">+44 (0) 208 1271742</span><br /><br />
                                        </div>
                                        <div>
                                            <b>Security</b><br /><br />
                                            MoMo Me takes reasonable steps to put in place and maintain electronic procedures and systems with 
                                            reference to accepted technological standards: 
                                            <ul>
                                                <li>To ensure the accuracy of;</li>
                                                <li>To prevent unauthorised access or disclosure of;</li>
                                                <li>To protect from misuse, loss, alteration or destruction of users’ personal information</li>
                                                <br /><br />
                                            </ul>
                                        </div>
                                        <div>
                                            <b>User’s Personal Information</b><br /><br />
                                            However, the user acknowledges that Internet communication and transactions are not 100% secure 
                                            or error free. In particular, information may not be secure in transit from the user to the MoMo Me 
                                            mobile app. Moreover, where the user provides particularly sensitive personal information such as 
                                            passwords, ID numbers, or other special access features on this site, it is the user’s responsibility 
                                            to safeguard them.<br /><br />

                                        </div>
                                        <div>
                                            <b>Linking to Third Party mobile apps</b><br /><br />
                                            MoMo Me is not responsible for the privacy practices of third party mobile apps to which there may 
                                            be links on the MoMo Me mobile app. MoMo Me advises users to read the privacy policy of each mobile 
                                            app which users visit.<br /><br />
                                        </div>
                                        <div>
                                            <b>Children</b><br /><br />
                                            The MoMo Me mobile app is not targeted to youths under the age of 18 and MoMo Me will not knowingly
                                            collect information from users in this age group. We encourage parents to talk to their children 
                                            about the use of the Internet and information they disclose to mobile apps.<br /><br />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default PrivacyPolicy;
