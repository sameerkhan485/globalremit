import React, { Component } from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

import Navbar from './components/layouts/Navbar';
import Home from './components/Home';
import AboutUs from './components/AboutUs';
import Faq from './components/Faq';
import ContactUs from './components/ContactUs';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsAndConditions from './components/TermsAndConditions';
import Footer from './components/layouts/Footer';

class App extends Component {
  render() {
    return (
      <Router>
        <Navbar />  
        <Route exact path="/" component={Home} />
        <Route exact path="/about-us" component={AboutUs} />
        <Route exact path="/faq" component={Faq} />
        <Route exact path="/contact-us" component={ContactUs} />
        <Route exact path="/privacy-policy" component={PrivacyPolicy} />
        <Route exact path="/terms-and-conditions" component={TermsAndConditions} />
        <Footer />
      </Router>
    );
  }
}

export default App;
