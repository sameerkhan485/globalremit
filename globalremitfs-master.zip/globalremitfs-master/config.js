module.exports = {
    USER: "info@globalremitfs.com",
    PASS: "VGKi632Wiw",
    'bodyLimit': '100kb'
}